import re

def censor_text(text, banned_words):
    censored_text = text
    for word in banned_words:
        pattern = r'\b' + re.escape(word) + r'\b'
        censored_text = re.sub(pattern, '*' * len(word), censored_text, flags=re.IGNORECASE)
    return censored_text

# Пример текста и списка запрещенных слов
text = "Этот текст содержит нецензурные слова, такие как 'проклятие' и 'оскорбление'."
banned_words = ['проклятие', 'оскорбление']

# Применение цензуры к тексту
censored_text = censor_text(text, banned_words)
print(censored_text)