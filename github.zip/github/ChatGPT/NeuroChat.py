import tensorflow as tf
from tensorflow.keras.layers import Embedding, LSTM, Dense
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Пример текстовых запросов пользователя и соответствующих ответов
texts = [
    "Привет, как дела?",
    "Что ты думаешь об искусственном интеллекте?",
    "Какая погода сегодня?",
    "Какой твой любимый цвет?",
    # Добавьте больше текстовых запросов и ответов, если необходимо
]

responses = [
    "Привет! У меня все отлично, спасибо за спрос.",
    "Я считаю, что искусственный интеллект - это удивительная технология, способная изменить мир.",
    "Сегодня облачно с прояснениями, температура около 20 градусов.",
    "Мой любимый цвет - черный, как мрак моих мыслей.",
    # Добавьте соответствующие ответы для каждого запроса выше
]

# Инициализация токенизатора
tokenizer = Tokenizer()
tokenizer.fit_on_texts(texts)

# Преобразование текста в последовательности чисел
sequences = tokenizer.texts_to_sequences(texts)

# Подготовка данных для обучения
max_len = max([len(seq) for seq in sequences])
padded_sequences = pad_sequences(sequences, maxlen=max_len, padding='post')

# Создание модели нейронной сети
model = tf.keras.Sequential([
    Embedding(len(tokenizer.word_index)+1, 50, input_length=max_len),
    LSTM(100),
    Dense(len(tokenizer.word_index)+1, activation='softmax')
])

model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Обучение модели
model.fit(padded_sequences, padded_sequences, epochs=50)

# Функция для предсказания ответа на текстовый запрос пользователя
def generate_response(input_text):
    input_seq = tokenizer.texts_to_sequences([input_text])
    padded_input = pad_sequences(input_seq, maxlen=max_len, padding='post')
    predicted_index = model.predict_classes(padded_input)[0]
    return list(tokenizer.word_index.keys())[list(tokenizer.word_index.values()).index(predicted_index)]

# Пример использования функции для получения ответа на запрос пользователя
user_input = "Какой сегодня день?"
response = generate_response(user_input)
print(response)